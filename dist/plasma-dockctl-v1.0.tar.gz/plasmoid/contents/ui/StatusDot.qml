import QtQuick
import org.kde.kirigami as Kirigami
import "DockStyle.js" as DS

Rectangle {
    id: dot

    property bool running: false
    property string health: ""

    width: Kirigami.Units.iconSizes.tiny
    height: width
    radius: width / 2

    color: {
        if (dot.running) {
            if (dot.health && dot.health !== "healthy") {
                return DS.orange;
            }
            return DS.green;
        }
        return DS.grey;
    }
}